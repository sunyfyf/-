import requests
import csv


headers = {
    "Accept": "application/json, text/javascript, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Pragma": "no-cache",
    "Referer": "http://www.osta.org.cn/fenlei.html",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "X-Requested-With": "XMLHttpRequest"
}
url = "http://www.osta.org.cn/json/fenlei/noc.json"
response = requests.get(url, headers=headers, verify=False)
json_data = response.json()
for data in json_data:
    code = data.get('code')
    definition = data.get('definition')
    name = data.get('name')
    res = [code, name, definition]
    with open("./result.csv", 'a', encoding='utf-8', newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(res)
    print(res)
